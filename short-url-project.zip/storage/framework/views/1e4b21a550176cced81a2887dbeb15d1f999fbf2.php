<?php if($message = Session::get('success')): ?>
    <p><?php echo e($message); ?></p>
<?php endif; ?>
<a href="/new">create</a>
<p>Your Quota Remaining <?php echo e(10-count($urls)); ?>/10</p>
<?php if(!$urls->isEmpty()): ?>
    <table>
        <tr>
            <td>long url</td>
            <td>short url</td>
            <td>create</td>
        </tr>
        <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($url->long_url); ?></td>
                <td><a href="/gt/<?php echo e($url->short_url); ?>" target="_blank"><?php echo e($url->short_url); ?></a></td>
                <td><?php echo e($url->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\short-url-project\resources\views/index.blade.php ENDPATH**/ ?>