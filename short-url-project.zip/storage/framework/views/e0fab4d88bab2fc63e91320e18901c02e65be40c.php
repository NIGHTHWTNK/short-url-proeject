<form action="/save" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="long_url" placeholder="Past Long URL">
    <button type="submit">Create Short URL</button>
</form>
<?php /**PATH C:\xampp\htdocs\short-url-project\resources\views/create.blade.php ENDPATH**/ ?>